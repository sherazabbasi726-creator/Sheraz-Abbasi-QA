Earthworks QA – Engr Muhammad Sheraz Abbasi
===========================================
Files: index.html (the whole app) + sw.js (offline cache).

Install on Android (offline use):
1. Put both files on any free https host, e.g. GitHub Pages (new repo -> upload -> Settings -> Pages).
2. Open the link once in Chrome WITH internet (it saves itself + 3D/PDF engines on first use).
3. Chrome menu (⋮) -> "Add to Home screen" / "Install app".
4. Data -> "Use my photo as icon" for your own icon (re-install to update it).

Data stays only on your phone. Use Data -> Download backup every week.
